﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Offline
{
    public partial class OfflineForm : Form
    {   /*
        public string myplaylist = "My Playlist";
        public WMPLib.IWMPPlaylist playlist;    // Danh sách file media
        public WMPLib.IWMPPlaylistArray playlistarray;  // Mảng chứa tất cả các file
        public WMPLib.IWMPMedia media; // Biến thể hiện cho mỗi file media
        */

        public OfflineForm()
        {
            InitializeComponent();
        }


        private void OfflineForm_Load(object sender, EventArgs e)
        {

        }

        /*
        private void CreatePlaylist(OpenFileDialog ofd, ListView lv)
        {
            int i = 0;

            foreach (string file in ofd.FileNames)
            {
                ListViewItem item = new ListViewItem(ofd.FileNames[i]);
                lv.Items.Add(Path.GetFileNameWithoutExtension(item.ToString()));
                i++;
                media = wmp.newMedia(file);
                playlist.appendItem(media);
            }

            wmp.currentPlaylist = playlist;
            wmp.Ctlcontrols.play();
        }
        */

        private void btnOpen_Click(object sender, EventArgs e)
        {
            lvPlaying.Items.Clear();

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                WMPLib.IWMPPlaylist playlist = wmp.newPlaylist("My Playlist", string.Empty);

                foreach (string file in ofd.FileNames)
                {
                    WMPLib.IWMPMedia media = wmp.newMedia(file);
                    playlist.appendItem(media);
                    lvPlaying.Items.Add(Path.GetFileNameWithoutExtension(file.ToString()));
                }

                wmp.currentPlaylist = playlist;
                wmp.Ctlcontrols.play();
                wmp.settings.autoStart = true;
                wmp.settings.setMode("loop", true);
            }
        }


        private void btnPlay_Click(object sender, EventArgs e)
        {
            wmp.Ctlcontrols.play();
        }


        private void btnPause_Click(object sender, EventArgs e)
        {
            wmp.Ctlcontrols.pause();
        }


        private void btnStop_Click(object sender, EventArgs e)
        {
            wmp.Ctlcontrols.stop();
        }


        private void btnFullScreen_Click(object sender, EventArgs e)
        {
            if (wmp.status.Contains("Play"))
            {
                wmp.fullScreen = true;
            }
        }


        private void lvPlaying_SelectedIndexChanged(object sender, EventArgs e)
        {
            //  wmp.URL = lvPlaying.FocusedItem.Text;
        }


        private void btnSavePlaylist_Click(object sender, EventArgs e)
        {
            if (!File.Exists("My Playlist.txt"))
            {
                File.Create("My Playlist.txt");
            }

            FileStream stream = File.OpenWrite("My Playlist.txt");
            StreamWriter writer = new StreamWriter(stream);

            foreach (ListViewItem item in lvPlaying.Items)
            {
                writer.WriteLine(item.Text);
            }

            writer.Close();
            stream.Close();
        }


        private void btnLoadPlaylist_Click(object sender, EventArgs e)
        {
            string line = string.Empty;
            FileStream stream = File.OpenRead("My Playlist.txt");
            StreamReader reader = new StreamReader(stream);

            lvPlaying.Items.Clear();
            WMPLib.IWMPPlaylist playlist = wmp.newPlaylist("My Playlist", string.Empty);

            while ((line = reader.ReadLine()) != null)
            {
                WMPLib.IWMPMedia media = wmp.newMedia(line);
                playlist.appendItem(media);
                lvPlaying.Items.Add(Path.GetFileNameWithoutExtension(line.ToString()));
            }

            wmp.currentPlaylist = playlist;
            wmp.Ctlcontrols.play();
            wmp.settings.autoStart = true;
            wmp.settings.setMode("loop", true);
        }
    }
}
